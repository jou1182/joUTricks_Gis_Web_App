# 🌍 JoUTricks GIS Viewer — الإصدار الثالث (v3)

تطبيق ويب تعليمي خفيف لعرض وتحليل البيانات الجغرافية مباشرة في المتصفح باستخدام **Leaflet**.

## ✨ الجديد في v3
- دعم رفع: **GeoJSON / Shapefile(.zip) / KML / KMZ / GPX / CSV / TopoJSON / WKT**
- نافذة **تعديل نمط الطبقات** (لون، سماكة، شفافية، حجم النقاط، شكل Marker/Circle)
- **حفظ الجلسة** في LocalStorage واستعادتها تلقائيًا
- **تصدير الطبقة** إلى GeoJSON أو Shapefile
- تحسينات شكلية متوافقة مع ألوان الهوية (الذهبي #CD980E والرمادي #504C5B)

> **ملاحظة:** دعم **GeoPackage (.gpkg)** داخل المتصفح سيتم إضافته في **v3.1** بسبب قيود مكتبات المتصفح، ننصح مؤقتًا بتحويله إلى GeoJSON أو Shapefile.

## 👤 التطوير
- Developed by **Dr. Youssef Seleim — JoUTricks Channel**  
- Supervised by **JoUTricks — Learn Smart. Work Smarter.**

## 🛠️ كيفية الاستخدام
1. افتح `index.html` في متصفح حديث.
2. اسحب الملف الجغرافي إلى منطقة الرفع أو اضغط لاختياره.
3. عدّل النمط من زر **نمط** لكل طبقة.
4. احفظ الجلسة واسترجعها لاحقًا من الأزرار في أعلى الصفحة.
5. صدّر الطبقة المختارة إلى GeoJSON أو Shapefile.

## 📦 المكتبات المستخدمة (المصادر)
- Leaflet (خرائط أساس) — CDN: unpkg
- shpjs (قراءة Shapefile) — jsDelivr
- JSZip (قراءة KMZ) — cdnjs
- togeojson (KML/GPX إلى GeoJSON) — cdnjs
- PapaParse (CSV) — cdnjs
- topojson-client (تحويل TopoJSON إلى GeoJSON) — unpkg
- shp-write (تصدير Shapefile) — unpkg
- terraformer-wkt-parser (قراءة WKT) — cdnjs

> تمت الإشارة إلى المصادر أعلاه مباشرة في وسوم `<script>` داخل `index.html`.
